export const initEditor = function () {
    api.log("Initializing editor...");
};