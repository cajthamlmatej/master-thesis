export const initPlayer = function () {
    api.log("Initializing editor...");
};